#ifndef WATERPOT

#include "library.h"

#define MIN_VAL 1
#define MAX_VAL 3

uint16_t waterpot_value()
{
    uint16_t liquidsensor_value = 0;
    ADMUX |= ((1 << MUX0) | (1 << MUX2));  //wybor kanalu, w tym wypadku kanal 7 (00111)
    ADCSRA |= (1 << ADSC);                 //start ADC conversion
    loop_until_bit_is_clear(ADCSRA, ADSC); //wait until ADC conversion is done
    liquidsensor_value = ADC;              //read ADC value in
    return liquidsensor_value;
}

int waterpot_level()
{
    uint16_t liquidsensor_value = waterpot_value();
    if (liquidsensor_value < MIN_VAL)
        return 1;
    if (liquidsensor_value > MAX_VAL)
        return 2;
    return 0;
}

#endif
