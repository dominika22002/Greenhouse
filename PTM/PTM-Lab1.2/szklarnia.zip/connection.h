#ifndef CONNECTION

#include "library.h"
#include "waterpot.h"
#include "watertank.h"
#include "temperature.h"
#include "lcd.h"

#define TIME 10000

void jakasfunkcja()
{

    // int waterpot_val = waterpot_level(waterpot_value());
    // int watertank_val = watertank_level(watertank_value());
}

void waterpot_switch()
{
    char text[20];
    switch (waterpot_level())
    {
    case 1:
        //wlacz pompe wody
        break;
    case 2:
        //zaduzo wody w doniczce(nie powinno miec miejsca)
        break;
    case 0:
        //poziom poprawny, nic nie rob
        break;

    default:
        break;
    }
}

int watertank_switch()
{
    char text[20];
    switch (watertank_level())
    {
    case 1:
        // za malo wody w zbiorniku, dolej wode
        sprintf(text, "Dolej wody!");
        LCD_String(text);
        sprintf(text, "%d / %d", watertank_value(), MIN_VAL);
        LCD_Command(0xC0);
        LCD_String(text);
        _delay_ms(250);
        LCD_Clear();
        return 1;
    case 2:
        //za duzo wody w zbiorniku, ochrzań czlowieka
        break;
    case 0:
        //poziom w normie, nic nie rob
        break;

    default:
        break;
    }
    return 0;
}

int temperature_switch(bool light_is_on, bool roof_is_up)
{   
    int dht_value[2];
    temperature_level(dht_value);

    switch (dht_value[0])
    {
    case 1: // wolgotnosc jest za mala, opusc klapy
        if (roof_is_up)
        {
            //opusc klape
        }
        
    case 2: // wolgotnosc jest za duza, podnies klapy
        if (!roof_is_up)
        {
            //podnies klape
        }
        break;
    case 0:
        //poziom w normie, nic nie rob
        break;
    default:
        break;
    }
    
    switch (dht_value[1])
    {
    case 4: //temperatura za niska, odpal swiatlo
        if (!light_is_on)
        {
            //odpal swiatlo
        }
        break;
    case 5: //temperatura za wysoka, zgas swiatlo
        if (light_is_on)
        {
            //zgas swiatlo
        }
        break;
    case 0:
        //poziom w normie, nic nie rob
        break;
    default:
        break;
    }
    return 0;
}

#endif