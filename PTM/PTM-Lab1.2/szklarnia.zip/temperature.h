#ifndef TEMPERATURE

#include "library.h"

#define DHT11_PIN 6
#define MIN_VAL_DH 1
#define MAX_VAL_DH 3
#define MIN_VAL_T 1
#define MAX_VAL_T 3


void Request() /* Microcontroller send start pulse/request */
{
	DDRD |= (1 << DHT11_PIN);
	PORTD &= ~(1 << DHT11_PIN); /* set to low pin */
	_delay_ms(20);				/* wait for 20ms */
	PORTD |= (1 << DHT11_PIN);	/* set to high pin */
}

void Response() /* receive response from DHT11 */
{
	DDRD &= ~(1 << DHT11_PIN);
	while (PIND & (1 << DHT11_PIN))
		;
	while ((PIND & (1 << DHT11_PIN)) == 0)
		;
	while (PIND & (1 << DHT11_PIN))
		;
}

uint8_t Receive_data() /* receive data */
{
	uint8_t c = 0;
	for (int q = 0; q < 8; q++)
	{
		while ((PIND & (1 << DHT11_PIN)) == 0)
			; /* check received bit 0 or 1 */
		_delay_us(30);
		if (PIND & (1 << DHT11_PIN)) /* if high pulse is greater than 30ms */
			c = (c << 1) | (0x01);	 /* then its logic HIGH */
		else						 /* otherwise its logic LOW */
			c = (c << 1);
		while (PIND & (1 << DHT11_PIN))
			;
	}
	return c;
}

int * temperature_level(int dht_value[2])
{
	dht_value[0] = 0;
	dht_value[1] = 0;
	uint8_t I_RH, D_RH, I_Temp, D_Temp, CheckSum;
	Request();				   /* send start pulse */
	Response();				   /* receive response */
	I_RH = Receive_data();	   /* store first eight bit in I_RH */
	D_RH = Receive_data();	   /* store next eight bit in D_RH */
	I_Temp = Receive_data();   /* store next eight bit in I_Temp */
	D_Temp = Receive_data();   /* store next eight bit in D_Temp */
	CheckSum = Receive_data(); /* store next eight bit in CheckSum */
	_delay_ms(10);

	if (I_RH < MIN_VAL_DH)
		dht_value[0] = 1;
	if (I_RH > MAX_VAL_DH)
		dht_value[0] = 2;
	if (I_Temp < MIN_VAL_T)
		dht_value[1] = 4;
	if (I_Temp > MAX_VAL_T)
		dht_value[1] = 5;
	return dht_value;

}

// int temperature_level()
// {
// 	uint16_t liquidsensor_value = temperature_value();
// 	if (liquidsensor_value < MIN_VAL)
// 		return 1;
// 	if (liquidsensor_value > MAX_VAL)
// 		return 2;
// 	return 0;
// }

#endif
