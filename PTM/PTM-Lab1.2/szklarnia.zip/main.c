#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/sfr_defs.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/iom32.h>

// #include "lcd.h"
// #include "waterpot.h"
// #include "watertank.h"
#include "connection.h"

static inline void initADC(void) { // czujnik wody 
ADMUX |= (1 << REFS0); //ustawienie napięcia ref na napięcie zasilania
//ADMUX |= ((1<<MUX0)| (1<<MUX2)); //wybor kanalu, w tym wypadku kanal 7 (00111)
ADCSRA |= (1 << ADPS1) | (1 << ADPS0); //czestotliwosc na 8
ADCSRA |= (1 << ADEN); //uruchomienie przetwornika ADC
}


int main(void) {
// inicjalizacja naszych rzeczy
	initADC();
	LCD_Init();	

// zmienne przechowujace wartosci
	uint16_t liquidsensor_value = 0;
	int busy = 0;
	char text[20];
	int time_sum=0;

    bool light_is_on = false;
    bool roof_is_up = false;


while (1) {

	busy = watertank_switch();
	waterpot_switch();
	temperature_switch(light_is_on, roof_is_up);

	// liquidsensor_value = waterpot_value();
	// sprintf(text, "Dziala!!!");
	// LCD_String(text);
	// sprintf(text, "%d",liquidsensor_value);
	// LCD_Command(0xC0);		/* Go to 2nd line*/
	// LCD_String(text);
    _delay_ms(250);
	LCD_Clear();
}

return (0);
} 


